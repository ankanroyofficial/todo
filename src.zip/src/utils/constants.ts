export const API = {
  auth: {
    login: '',
    signup: '', 
  },
  user: {
    profile: '', 
  },
}; 