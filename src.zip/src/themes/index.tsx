import Colors from "./Colors";
import Fonts from "./Fonts";
import Icons from "./Icons";
import Images from "./Images";

export {Colors,Fonts,Icons,Images};