const Fonts = {};

export default Fonts;
