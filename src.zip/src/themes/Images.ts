const Images = {};

export default Images;
